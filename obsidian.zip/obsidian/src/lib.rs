mod aggregator;
pub mod core;
mod vectorizer;
